<?php
	session_start();
	$_SESSION = array();
	session_destroy();
?>

<html>
	<head>
		<title>ВПоиске</title>
	</head>
   <style>
   body {
    background: url(/pics/background.jpg) no-repeat;
     -moz-background-size: 100%;
     -webkit-background-size: 100%;
     -o-background-size: 100%;
     background-size: 100%;
 	}
  </style>
	<body link="black" vlink="black" alink="black" bgcolor="black">
		<form method="post" action="/scripts/auth.php">
			<h1>Войти в систему </h1>
			<p><input type="text" autofocus maxlength="16" size="16" name="login" value=""></input></p>
			<p><input type="password" maxlength="16" size="16" name="pass"></input></p>
			<p><input type="submit" value="войти в систему"></input></p>
		</form>
	</body>
</html>
