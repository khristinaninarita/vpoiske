<html>
	<head>
		<title>ВПоиске</title>
	</head>
   <style>
   body {
    background: url(/pics/background.jpg) no-repeat;
     -moz-background-size: 100%;
     -webkit-background-size: 100%;
     -o-background-size: 100%;
     background-size: 100%;
 	}
  </style>
	<body link="black" vlink="black" alink="black" bgcolor="black">
		<form method="post" action="auth.php">
	  <input name="q" id="form-query" value="" size="60" placeholder="Поиск по сайту"> 
		<input src="/pics/search.png" type="image" style="vertical-align: bottom; padding: 0;"/></form>
   	<p><H1><B> Показать термины </B></H1></p>
   	<a href="medic.html">Медицина/ </a>
  	<a href="prog.html">Финансы/ </a>
   	<a href="finans.html">Программирование/ </a>
   	<a href="obrazov.html">Образование/ </a>
    <a href="vset.html">Все термины</a>
	</body>
</html>
