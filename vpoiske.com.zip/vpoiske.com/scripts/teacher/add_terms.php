<?php
	session_start();
	if (!isset($_SESSION['login']))
	{
		Header("Location: /index.php");
	}

	require_once("queries.php");

	// задаем набор символов по умолчанию
	if (!mysqli_set_charset($link, "utf8"))
	{
		die("Ошибка при загрузке набора UTF8: " . mysqli_error($link) . "\n");
	}

	// экранируем специальные символы
	$term_ru = mysqli_real_escape_string($link, $_POST['termru']);
	$term_en = mysqli_real_escape_string($link, $_POST['termen']);
	$abbr_ru = mysqli_real_escape_string($link, $_POST['abbrru']);
	$abbr_en = mysqli_real_escape_string($link, $_POST['abbren']);
	//$def_ru  = mysqli_real_escape_string($link, $_POST['def_ru']);
	//$def_en  = mysqli_real_escape_string($link, $_POST['def_en']);
	if (!empty($term_ru))
	{
		Header("Location: /scripts/teacher/terms.php");
	}
?>
