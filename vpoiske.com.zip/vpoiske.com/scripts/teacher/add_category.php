<?php
	session_start();
  if (!isset($_SESSION['login']))
  {
  	Header("Location: /index.php");
  }
  
	require_once("queries.php");
	
	// задаем набор символов по умолчанию
	if (!mysqli_set_charset($link, "utf8"))
	{
		die("Ошибка при загрузке набора UTF8: " . mysqli_error($link) . "\n");
	}

	// экранируем специальные символы
	$catname = mysqli_real_escape_string($link, $_POST['catname']);
	if (!isset($catname))
	{
		Header("Location: /scripts/teacher/main.php");
	}

	$query = get_id_category_by_catname($link, $catname);
	$row = mysqli_fetch_row($query);
	$_SESSION['id_category'] = $row[0]; // заносим в сессию идентификатор категории вносимого

	Header("Location: terms.php");
?>
