<?php
	session_start();
	if (!isset($_SESSION['login']))
	{
		Header("Location: /index.php");
	}
?>

<html>
	<head>
		<title>ВПоиске</title>
	</head>
   <style>
   body {
    background: url(/pics/background.jpg) no-repeat;
     -moz-background-size: 100%;
     -webkit-background-size: 100%;
     -o-background-size: 100%;
     background-size: 100%;
 	}
  </style>
	<body link="black" vlink="black" alink="black" bgcolor="black">
		<form method="post" action="add_category.php">
   	<p><H1><B> Список тематических категорий </B></H1></p>
		<?php
			require_once("queries.php");
			$query = get_categories($link);
			echo "<select name=\"catname\">";
			while (list($catname) = mysqli_fetch_row($query))
			{
				echo "<option>$catname</option>";
			}
			echo "</select>";
		?>
		<input type="submit" name="submit" value="Далее"></input>
		</form>
	</body>
</html>
