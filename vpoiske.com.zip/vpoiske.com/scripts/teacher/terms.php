﻿<?php
	session_start();
	if (!isset($_SESSION['login']))
	{
		Header("Location: /index.php");
	}
?>
<head>
	<title>ВПоиске</title>
	<link rel="stylesheet" type="text/css" href="/style.css">
</head>
   <style>
   body {
    background: url(/pics/background.jpg) no-repeat;
     -moz-background-size: 100%;
     -webkit-background-size: 100%;
     -o-background-size: 100%;
     background-size: 100%;
 	}
  </style>
	<body link="black" vlink="black" alink="black" bgcolor="black">
		<form method="post" action="add_terms.php">
   	<p><H1><B> Введите данные термина: </B></H1></p>
		<table>
		<tr>
			<td class="bolder">Термин (рус)</td>
			<td><input type="text" name="termru"></input></td>
		</tr>
		<tr>
			<td class="bolder">Термин (анг)</td>
			<td><input type="text" name="termen"></input></td>
		</tr>
		<tr>
			<td class="bolder">Аббр (рус)</td>
			<td><input type="text" name="abbrru"></input></td>
		</tr>
		<tr>
			<td class="bolder">Аббр (анг)</td>
			<td><input type="text" name="abbren"></input></td>
		</tr>
		<!--<tr>
			<td class="bolder">Опр (рус)</td>
			<td><input type="text" rows="8" cols="60" name="def_ru"></input></td>
		</tr>
		<tr>
			<td class="bolder">Опр (анг)</td>
			<td><input type="text" rows="8" cols="60" name="def_en"></input></td>
		</tr>-->
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Внести термин"></input></td>
		</tr>
		</table>
		</form>
	</body>
</html>
